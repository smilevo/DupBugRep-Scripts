1. highlighted in green: correctly classified by BERT but misclassified by Roberta

2. highlighted in blue: correctly classified by BERT but misclassified by S-BERT

3. highlighted in orange: correctly classified by BERT but misclassified by both S-BERT and Roberta